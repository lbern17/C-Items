﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Tuition_Increase
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void tuitionListBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void calcButton_Click(object sender, EventArgs e)
        {
            double percent = .2;
            double tuition = 6000;

            for (int year = 1; year <= 5; year++)
            {
                double newTuitionPercent = tuition * percent;
                tuition = tuition + newTuitionPercent;
                double total = 0;
                total = (total + tuition) * 2;
                tuitionListBox.Items.Add("New Semester Tuition for Year" + year + " : " + "$" + tuition);
                tuitionListBox.Items.Add("Total Tuition for Year " + year + " : " + "$" + total);
                tuitionListBox.Items.Add("-----------------------------------------------");
            }
        }

     
    }
}
