﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Software_Sales
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calcButton_Click(object sender, EventArgs e)
        {
            int sp; //Software packages purchased
            
            sp = int.Parse(packageBox.Text);

            if(sp >= 10 && sp <= 19)
            {
                double pb = sp * 99; //The price before the discount
                double fs = pb - (pb * .2); //The final sales price

                MessageBox.Show("Price Before Discount: $" + pb + " | Discount Amount: 20% | "
                                + "Final Sales Price: $" + fs);
            }
            if (sp >= 20 && sp <= 49)
            {
                double pb = sp * 99; //The price before the discount
                double fs = pb - (pb * .3); //The final sales price

                MessageBox.Show("Price Before Discount: $" + pb + " | Discount Amount: 30% | "
                                + "Final Sales Price: $" + fs);
            }
            if (sp >= 50 && sp <= 99)
            {
                double pb = sp * 99; //The price before the discount
                double fs = pb - (pb * .4); //The final sales price

                MessageBox.Show("Price Before Discount: $" + pb + " | Discount Amount: 40% | "
                                + "Final Sales Price: $" + fs);
            }
            if (sp > 99)
            {
                double pb = sp * 99; //The price before the discount
                double fs = pb - (pb * .5); //The final sales price

                MessageBox.Show("Price Before Discount: $" + pb + " | Discount Amount: 50% | "
                                + "Final Sales Price: $" + fs);
            }
            if (sp < 10)
            {
                double pb = sp * 99; //The price before the discount
               
                MessageBox.Show("Final Sales Price: $" + pb);
            }
        }
    }
}
