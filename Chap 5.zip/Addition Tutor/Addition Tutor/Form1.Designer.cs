﻿namespace Addition_Tutor
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.calcButton = new System.Windows.Forms.Button();
            this.welcomeLabel = new System.Windows.Forms.Label();
            this.num1Label = new System.Windows.Forms.Label();
            this.plusLabel = new System.Windows.Forms.Label();
            this.num2Label = new System.Windows.Forms.Label();
            this.equalLabel = new System.Windows.Forms.Label();
            this.inputBox = new System.Windows.Forms.TextBox();
            this.beginButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(104, 112);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(134, 23);
            this.calcButton.TabIndex = 0;
            this.calcButton.Text = "Check Your Answer!";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // welcomeLabel
            // 
            this.welcomeLabel.AutoSize = true;
            this.welcomeLabel.Location = new System.Drawing.Point(101, 9);
            this.welcomeLabel.Name = "welcomeLabel";
            this.welcomeLabel.Size = new System.Drawing.Size(154, 13);
            this.welcomeLabel.TabIndex = 1;
            this.welcomeLabel.Text = "Welcome to the Addition Tutor!";
            // 
            // num1Label
            // 
            this.num1Label.AutoSize = true;
            this.num1Label.BackColor = System.Drawing.SystemColors.ControlLight;
            this.num1Label.Location = new System.Drawing.Point(66, 43);
            this.num1Label.MinimumSize = new System.Drawing.Size(50, 15);
            this.num1Label.Name = "num1Label";
            this.num1Label.Size = new System.Drawing.Size(50, 15);
            this.num1Label.TabIndex = 2;
            // 
            // plusLabel
            // 
            this.plusLabel.AutoSize = true;
            this.plusLabel.Location = new System.Drawing.Point(122, 45);
            this.plusLabel.Name = "plusLabel";
            this.plusLabel.Size = new System.Drawing.Size(13, 13);
            this.plusLabel.TabIndex = 3;
            this.plusLabel.Text = "+";
            // 
            // num2Label
            // 
            this.num2Label.AutoSize = true;
            this.num2Label.BackColor = System.Drawing.SystemColors.ControlLight;
            this.num2Label.Location = new System.Drawing.Point(141, 45);
            this.num2Label.MinimumSize = new System.Drawing.Size(50, 15);
            this.num2Label.Name = "num2Label";
            this.num2Label.Size = new System.Drawing.Size(50, 15);
            this.num2Label.TabIndex = 4;
            // 
            // equalLabel
            // 
            this.equalLabel.AutoSize = true;
            this.equalLabel.Location = new System.Drawing.Point(197, 47);
            this.equalLabel.Name = "equalLabel";
            this.equalLabel.Size = new System.Drawing.Size(13, 13);
            this.equalLabel.TabIndex = 5;
            this.equalLabel.Text = "=";
            // 
            // inputBox
            // 
            this.inputBox.Location = new System.Drawing.Point(216, 45);
            this.inputBox.Name = "inputBox";
            this.inputBox.Size = new System.Drawing.Size(50, 20);
            this.inputBox.TabIndex = 6;
            // 
            // beginButton
            // 
            this.beginButton.Location = new System.Drawing.Point(135, 73);
            this.beginButton.Name = "beginButton";
            this.beginButton.Size = new System.Drawing.Size(75, 23);
            this.beginButton.TabIndex = 7;
            this.beginButton.Text = "Begin!";
            this.beginButton.UseVisualStyleBackColor = true;
            this.beginButton.Click += new System.EventHandler(this.beginButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(135, 150);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 8;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(344, 184);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.beginButton);
            this.Controls.Add(this.inputBox);
            this.Controls.Add(this.equalLabel);
            this.Controls.Add(this.num2Label);
            this.Controls.Add(this.plusLabel);
            this.Controls.Add(this.num1Label);
            this.Controls.Add(this.welcomeLabel);
            this.Controls.Add(this.calcButton);
            this.Name = "Form1";
            this.Text = "The Addition Tutor";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button calcButton;
        private System.Windows.Forms.Label welcomeLabel;
        private System.Windows.Forms.Label num1Label;
        private System.Windows.Forms.Label plusLabel;
        private System.Windows.Forms.Label num2Label;
        private System.Windows.Forms.Label equalLabel;
        private System.Windows.Forms.TextBox inputBox;
        private System.Windows.Forms.Button beginButton;
        private System.Windows.Forms.Button exitButton;
    }
}

