﻿namespace LatinTranslator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.instructionlabel = new System.Windows.Forms.Label();
            this.translationlabel = new System.Windows.Forms.Label();
            this.sinisterbutton = new System.Windows.Forms.Button();
            this.dexterbutton = new System.Windows.Forms.Button();
            this.mediumbutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // instructionlabel
            // 
            this.instructionlabel.AutoSize = true;
            this.instructionlabel.Location = new System.Drawing.Point(12, 9);
            this.instructionlabel.Name = "instructionlabel";
            this.instructionlabel.Size = new System.Drawing.Size(308, 13);
            this.instructionlabel.TabIndex = 0;
            this.instructionlabel.Text = "Welcome to the Latin Translator! Select a word to be translated!";
            // 
            // translationlabel
            // 
            this.translationlabel.AutoSize = true;
            this.translationlabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.translationlabel.Font = new System.Drawing.Font("Perpetua Titling MT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.translationlabel.Location = new System.Drawing.Point(92, 33);
            this.translationlabel.MinimumSize = new System.Drawing.Size(150, 25);
            this.translationlabel.Name = "translationlabel";
            this.translationlabel.Size = new System.Drawing.Size(150, 25);
            this.translationlabel.TabIndex = 2;
            // 
            // sinisterbutton
            // 
            this.sinisterbutton.Location = new System.Drawing.Point(15, 70);
            this.sinisterbutton.Name = "sinisterbutton";
            this.sinisterbutton.Size = new System.Drawing.Size(75, 23);
            this.sinisterbutton.TabIndex = 3;
            this.sinisterbutton.Text = "Sinister!";
            this.sinisterbutton.UseVisualStyleBackColor = true;
            this.sinisterbutton.Click += new System.EventHandler(this.sinisterbutton_Click);
            // 
            // dexterbutton
            // 
            this.dexterbutton.Location = new System.Drawing.Point(236, 70);
            this.dexterbutton.Name = "dexterbutton";
            this.dexterbutton.Size = new System.Drawing.Size(75, 23);
            this.dexterbutton.TabIndex = 4;
            this.dexterbutton.Text = "Dexter!";
            this.dexterbutton.UseVisualStyleBackColor = true;
            this.dexterbutton.Click += new System.EventHandler(this.dexterbutton_Click);
            // 
            // mediumbutton
            // 
            this.mediumbutton.Location = new System.Drawing.Point(131, 70);
            this.mediumbutton.Name = "mediumbutton";
            this.mediumbutton.Size = new System.Drawing.Size(75, 23);
            this.mediumbutton.TabIndex = 5;
            this.mediumbutton.Text = "Medium!";
            this.mediumbutton.UseVisualStyleBackColor = true;
            this.mediumbutton.Click += new System.EventHandler(this.mediumbutton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(323, 109);
            this.Controls.Add(this.mediumbutton);
            this.Controls.Add(this.dexterbutton);
            this.Controls.Add(this.sinisterbutton);
            this.Controls.Add(this.translationlabel);
            this.Controls.Add(this.instructionlabel);
            this.Name = "Form1";
            this.Text = "Latin Translator!";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label instructionlabel;
        private System.Windows.Forms.Label translationlabel;
        private System.Windows.Forms.Button sinisterbutton;
        private System.Windows.Forms.Button dexterbutton;
        private System.Windows.Forms.Button mediumbutton;
    }
}

