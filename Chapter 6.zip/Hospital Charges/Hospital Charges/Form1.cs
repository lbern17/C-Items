﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Charges
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calcButton_Click(object sender, EventArgs e)
        {
            double days = double.Parse(daysBox.Text);
            double surgery = double.Parse(surgeryBox.Text);
            double rehab = double.Parse(rehabBox.Text);
            double lab = double.Parse(labBox.Text);
            double meds = double.Parse(medBox.Text);
            double stayCharge = calcStayCharges(days);
            double miscCharges = calcMiscCharges(surgery, rehab, lab, meds);
            double totalCharges = calcTotalCharges(stayCharge, miscCharges);

            

            MessageBox.Show("Your total charges for your hospital stay is $" + 
                              totalCharges +".");
        }

            public double calcStayCharges(double d)
            {
                double stayCharge = 350 * d;
                return stayCharge;
            }
            
            public double calcMiscCharges(double s, double r, double l, double m)
            {
                double miscCharges = s + r + l + m;
                return miscCharges;
            }

            public double calcTotalCharges(double s, double m)
            {
                double totalCharges = s + m;
                return totalCharges;
            }
    
        
    }
}
