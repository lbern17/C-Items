﻿namespace Distance_Traveled
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.welcomeLabel = new System.Windows.Forms.Label();
            this.speedLabel = new System.Windows.Forms.Label();
            this.mphBox = new System.Windows.Forms.TextBox();
            this.fiveButton = new System.Windows.Forms.Button();
            this.eightButton = new System.Windows.Forms.Button();
            this.twelveButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.travelLabel = new System.Windows.Forms.Label();
            this.distanceLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // welcomeLabel
            // 
            this.welcomeLabel.AutoSize = true;
            this.welcomeLabel.Location = new System.Drawing.Point(83, 20);
            this.welcomeLabel.Name = "welcomeLabel";
            this.welcomeLabel.Size = new System.Drawing.Size(219, 13);
            this.welcomeLabel.TabIndex = 0;
            this.welcomeLabel.Text = "Welcome to the Distance Traveled Machine!";
            // 
            // speedLabel
            // 
            this.speedLabel.AutoSize = true;
            this.speedLabel.Location = new System.Drawing.Point(35, 55);
            this.speedLabel.Name = "speedLabel";
            this.speedLabel.Size = new System.Drawing.Size(173, 13);
            this.speedLabel.TabIndex = 1;
            this.speedLabel.Text = "Enter your speed in Miles Per Hour:";
            // 
            // mphBox
            // 
            this.mphBox.Location = new System.Drawing.Point(233, 55);
            this.mphBox.Name = "mphBox";
            this.mphBox.Size = new System.Drawing.Size(100, 20);
            this.mphBox.TabIndex = 2;
            // 
            // fiveButton
            // 
            this.fiveButton.Location = new System.Drawing.Point(24, 116);
            this.fiveButton.Name = "fiveButton";
            this.fiveButton.Size = new System.Drawing.Size(75, 56);
            this.fiveButton.TabIndex = 3;
            this.fiveButton.Text = "Distance After 5 Hours";
            this.fiveButton.UseVisualStyleBackColor = true;
            this.fiveButton.Click += new System.EventHandler(this.fiveButton_Click);
            // 
            // eightButton
            // 
            this.eightButton.Location = new System.Drawing.Point(105, 116);
            this.eightButton.Name = "eightButton";
            this.eightButton.Size = new System.Drawing.Size(75, 56);
            this.eightButton.TabIndex = 4;
            this.eightButton.Text = "Distance After Eight Hours";
            this.eightButton.UseVisualStyleBackColor = true;
            this.eightButton.Click += new System.EventHandler(this.eightButton_Click);
            // 
            // twelveButton
            // 
            this.twelveButton.Location = new System.Drawing.Point(186, 116);
            this.twelveButton.Name = "twelveButton";
            this.twelveButton.Size = new System.Drawing.Size(75, 56);
            this.twelveButton.TabIndex = 5;
            this.twelveButton.Text = "Distance After Twelve Hours";
            this.twelveButton.UseVisualStyleBackColor = true;
            this.twelveButton.Click += new System.EventHandler(this.twelveButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(267, 133);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 6;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // travelLabel
            // 
            this.travelLabel.AutoSize = true;
            this.travelLabel.Location = new System.Drawing.Point(111, 87);
            this.travelLabel.Name = "travelLabel";
            this.travelLabel.Size = new System.Drawing.Size(97, 13);
            this.travelLabel.TabIndex = 7;
            this.travelLabel.Text = "Distance Traveled:";
            // 
            // distanceLabel
            // 
            this.distanceLabel.AutoSize = true;
            this.distanceLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.distanceLabel.Location = new System.Drawing.Point(233, 87);
            this.distanceLabel.MinimumSize = new System.Drawing.Size(100, 0);
            this.distanceLabel.Name = "distanceLabel";
            this.distanceLabel.Size = new System.Drawing.Size(100, 15);
            this.distanceLabel.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(379, 184);
            this.Controls.Add(this.distanceLabel);
            this.Controls.Add(this.travelLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.twelveButton);
            this.Controls.Add(this.eightButton);
            this.Controls.Add(this.fiveButton);
            this.Controls.Add(this.mphBox);
            this.Controls.Add(this.speedLabel);
            this.Controls.Add(this.welcomeLabel);
            this.Name = "Form1";
            this.Text = "Distance Traveled";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label welcomeLabel;
        private System.Windows.Forms.Label speedLabel;
        private System.Windows.Forms.TextBox mphBox;
        private System.Windows.Forms.Button fiveButton;
        private System.Windows.Forms.Button eightButton;
        private System.Windows.Forms.Button twelveButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label travelLabel;
        private System.Windows.Forms.Label distanceLabel;
    }
}

