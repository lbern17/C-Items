﻿namespace Tuition_Increase
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.welcomeLabel = new System.Windows.Forms.Label();
            this.tuitionListBox = new System.Windows.Forms.ListBox();
            this.calcButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // welcomeLabel
            // 
            this.welcomeLabel.AutoSize = true;
            this.welcomeLabel.Location = new System.Drawing.Point(69, 19);
            this.welcomeLabel.Name = "welcomeLabel";
            this.welcomeLabel.Size = new System.Drawing.Size(170, 13);
            this.welcomeLabel.TabIndex = 0;
            this.welcomeLabel.Text = "Welcome to the Tuition Calculator!";
            // 
            // tuitionListBox
            // 
            this.tuitionListBox.FormattingEnabled = true;
            this.tuitionListBox.Location = new System.Drawing.Point(33, 52);
            this.tuitionListBox.Name = "tuitionListBox";
            this.tuitionListBox.Size = new System.Drawing.Size(242, 199);
            this.tuitionListBox.TabIndex = 1;
            this.tuitionListBox.SelectedIndexChanged += new System.EventHandler(this.tuitionListBox_SelectedIndexChanged);
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(90, 268);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(112, 46);
            this.calcButton.TabIndex = 2;
            this.calcButton.Text = "Calculate Tuition!";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(296, 338);
            this.Controls.Add(this.calcButton);
            this.Controls.Add(this.tuitionListBox);
            this.Controls.Add(this.welcomeLabel);
            this.Name = "Form1";
            this.Text = "Tuition Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label welcomeLabel;
        private System.Windows.Forms.ListBox tuitionListBox;
        private System.Windows.Forms.Button calcButton;
    }
}

