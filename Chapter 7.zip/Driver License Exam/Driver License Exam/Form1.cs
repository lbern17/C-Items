﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Driver_License_Exam
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calc1button_Click(object sender, EventArgs e)
        {
            String[] answers = { "b", "d", "a", "a", "c", "a", "b", "a", "c", "d", "b", "c", "d", "a", "d",
                                  "c", "c", "b", "d", "a"};

            String[] test1 = new String[20];

            List<string> wrong = new List<string>();

            int correctNum = 0; 
            int x = 0;
            int questionNum = 0;

            StreamReader inputFile = File.OpenText("TestOne.txt");

            while (!inputFile.EndOfStream)
            {
                test1[x] = inputFile.ReadLine();

                if (test1[x] == answers[x])
                    correctNum++;
                else
                {
                    questionNum = x + 1;
                    wrong.Add(questionNum.ToString());
                }

                x++;

            }

            inputFile.Close();

            if (correctNum >= 15)
            {
                displayBox.Items.Add("Congratulations, you passed!");
            }
            else
            {
                displayBox.Items.Add("Sorry, bucko, you failed! Try harder!");
            }

            foreach (String wrongAnswers in wrong)
            {
                displayBox.Items.Add(wrongAnswers);
            }

    }

        private void calc2Button_Click(object sender, EventArgs e)
        {
            String[] answers = { "b", "d", "a", "a", "c", "a", "b", "a", "c", "d", "b", "c", "d", "a", "d",
                                  "c", "c", "b", "d", "a"};

            String[] test2 = new String[20];

            List<string> wrong = new List<string>();

            int correctNum = 0;
            int x = 0;
            int questionNum = 0;

            StreamReader inputFile = File.OpenText("TestTwo.txt");

            while (!inputFile.EndOfStream)
            {
                test2[x] = inputFile.ReadLine();

                if (test2[x] == answers[x])
                    correctNum++;
                else
                {
                    questionNum = x + 1;
                    wrong.Add(questionNum.ToString());
                }

                x++;

            }
        
            inputFile.Close();

            if (correctNum >= 15)
            {
                displayBox.Items.Add("Congratulations, you passed!");
            }
            else
            {
                displayBox.Items.Add("Sorry, bucko, you failed! Try harder!");
            }

            foreach (String wrongAnswers in wrong)
            {
                displayBox.Items.Add(wrongAnswers);
            }

            }
        }
    }
