﻿namespace Driver_License_Exam
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.calc1button = new System.Windows.Forms.Button();
            this.displayBox = new System.Windows.Forms.ListBox();
            this.calc2Button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // calc1button
            // 
            this.calc1button.Location = new System.Drawing.Point(97, 12);
            this.calc1button.Name = "calc1button";
            this.calc1button.Size = new System.Drawing.Size(105, 23);
            this.calc1button.TabIndex = 0;
            this.calc1button.Text = "Grade Test 1";
            this.calc1button.UseVisualStyleBackColor = true;
            this.calc1button.Click += new System.EventHandler(this.calc1button_Click);
            // 
            // displayBox
            // 
            this.displayBox.FormattingEnabled = true;
            this.displayBox.Location = new System.Drawing.Point(12, 103);
            this.displayBox.Name = "displayBox";
            this.displayBox.Size = new System.Drawing.Size(260, 173);
            this.displayBox.TabIndex = 1;
            // 
            // calc2Button
            // 
            this.calc2Button.Location = new System.Drawing.Point(97, 60);
            this.calc2Button.Name = "calc2Button";
            this.calc2Button.Size = new System.Drawing.Size(105, 23);
            this.calc2Button.TabIndex = 2;
            this.calc2Button.Text = "Grade Test 2";
            this.calc2Button.UseVisualStyleBackColor = true;
            this.calc2Button.Click += new System.EventHandler(this.calc2Button_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 288);
            this.Controls.Add(this.calc2Button);
            this.Controls.Add(this.displayBox);
            this.Controls.Add(this.calc1button);
            this.Name = "Form1";
            this.Text = "Driver License Exam";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button calc1button;
        private System.Windows.Forms.ListBox displayBox;
        private System.Windows.Forms.Button calc2Button;
    }
}

