﻿namespace Time_Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.welcomeLabel = new System.Windows.Forms.Label();
            this.instructionLabel = new System.Windows.Forms.Label();
            this.secondBox = new System.Windows.Forms.TextBox();
            this.minutesLabel = new System.Windows.Forms.Label();
            this.minutesBox = new System.Windows.Forms.Label();
            this.calcButton = new System.Windows.Forms.Button();
            this.hourBox = new System.Windows.Forms.Label();
            this.hourLabel = new System.Windows.Forms.Label();
            this.dayBox = new System.Windows.Forms.Label();
            this.dayLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // welcomeLabel
            // 
            this.welcomeLabel.AutoSize = true;
            this.welcomeLabel.Location = new System.Drawing.Point(38, 9);
            this.welcomeLabel.Name = "welcomeLabel";
            this.welcomeLabel.Size = new System.Drawing.Size(205, 13);
            this.welcomeLabel.TabIndex = 0;
            this.welcomeLabel.Text = "Welcome to the Time Calculator Machine!";
            // 
            // instructionLabel
            // 
            this.instructionLabel.AutoSize = true;
            this.instructionLabel.Location = new System.Drawing.Point(12, 36);
            this.instructionLabel.Name = "instructionLabel";
            this.instructionLabel.Size = new System.Drawing.Size(141, 13);
            this.instructionLabel.TabIndex = 1;
            this.instructionLabel.Text = "Enter a Number of Seconds:";
            // 
            // secondBox
            // 
            this.secondBox.Location = new System.Drawing.Point(156, 33);
            this.secondBox.Name = "secondBox";
            this.secondBox.Size = new System.Drawing.Size(141, 20);
            this.secondBox.TabIndex = 2;
            // 
            // minutesLabel
            // 
            this.minutesLabel.AutoSize = true;
            this.minutesLabel.Location = new System.Drawing.Point(65, 105);
            this.minutesLabel.Name = "minutesLabel";
            this.minutesLabel.Size = new System.Drawing.Size(85, 13);
            this.minutesLabel.TabIndex = 3;
            this.minutesLabel.Text = "Minutes Passed:";
            // 
            // minutesBox
            // 
            this.minutesBox.AutoSize = true;
            this.minutesBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.minutesBox.Location = new System.Drawing.Point(156, 105);
            this.minutesBox.MinimumSize = new System.Drawing.Size(135, 22);
            this.minutesBox.Name = "minutesBox";
            this.minutesBox.Size = new System.Drawing.Size(135, 22);
            this.minutesBox.TabIndex = 4;
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(108, 59);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(97, 26);
            this.calcButton.TabIndex = 5;
            this.calcButton.Text = "Calculate!";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // hourBox
            // 
            this.hourBox.AutoSize = true;
            this.hourBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hourBox.Location = new System.Drawing.Point(156, 145);
            this.hourBox.MinimumSize = new System.Drawing.Size(135, 22);
            this.hourBox.Name = "hourBox";
            this.hourBox.Size = new System.Drawing.Size(135, 22);
            this.hourBox.TabIndex = 6;
            // 
            // hourLabel
            // 
            this.hourLabel.AutoSize = true;
            this.hourLabel.Location = new System.Drawing.Point(74, 145);
            this.hourLabel.Name = "hourLabel";
            this.hourLabel.Size = new System.Drawing.Size(76, 13);
            this.hourLabel.TabIndex = 7;
            this.hourLabel.Text = "Hours Passed:";
            // 
            // dayBox
            // 
            this.dayBox.AutoSize = true;
            this.dayBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dayBox.Location = new System.Drawing.Point(156, 180);
            this.dayBox.MinimumSize = new System.Drawing.Size(135, 22);
            this.dayBox.Name = "dayBox";
            this.dayBox.Size = new System.Drawing.Size(135, 22);
            this.dayBox.TabIndex = 8;
            // 
            // dayLabel
            // 
            this.dayLabel.AutoSize = true;
            this.dayLabel.Location = new System.Drawing.Point(77, 180);
            this.dayLabel.Name = "dayLabel";
            this.dayLabel.Size = new System.Drawing.Size(72, 13);
            this.dayLabel.TabIndex = 9;
            this.dayLabel.Text = "Days Passed:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(312, 226);
            this.Controls.Add(this.dayLabel);
            this.Controls.Add(this.dayBox);
            this.Controls.Add(this.hourLabel);
            this.Controls.Add(this.hourBox);
            this.Controls.Add(this.calcButton);
            this.Controls.Add(this.minutesBox);
            this.Controls.Add(this.minutesLabel);
            this.Controls.Add(this.secondBox);
            this.Controls.Add(this.instructionLabel);
            this.Controls.Add(this.welcomeLabel);
            this.Name = "Form1";
            this.Text = "Time Calculator Machine";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label welcomeLabel;
        private System.Windows.Forms.Label instructionLabel;
        private System.Windows.Forms.TextBox secondBox;
        private System.Windows.Forms.Label minutesLabel;
        private System.Windows.Forms.Label minutesBox;
        private System.Windows.Forms.Button calcButton;
        private System.Windows.Forms.Label hourBox;
        private System.Windows.Forms.Label hourLabel;
        private System.Windows.Forms.Label dayBox;
        private System.Windows.Forms.Label dayLabel;
    }
}

