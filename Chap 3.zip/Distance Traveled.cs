﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Distance_Traveled
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void fiveButton_Click(object sender, EventArgs e)
        {
            double mph;
            double distance;

            mph = double.Parse(mphBox.Text);

            distance = mph * 5;

            distanceLabel.Text = distance.ToString("n1");
        }

        private void eightButton_Click(object sender, EventArgs e)
        {
            double mph;
            double distance;

            mph = double.Parse(mphBox.Text);

            distance = mph * 8;

            distanceLabel.Text = distance.ToString("n1");
        }

        private void twelveButton_Click(object sender, EventArgs e)
        {
            double mph;
            double distance;

            mph = double.Parse(mphBox.Text);

            distance = mph * 12;

            distanceLabel.Text = distance.ToString("n1");
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
