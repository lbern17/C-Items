﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Addition_Tutor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void beginButton_Click(object sender, EventArgs e)
        {
            Random n = new Random();
            int num1 = n.Next(100, 500);
            int num2 = n.Next(100, 500);
            num1Label.Text = ("" + num1);
            num2Label.Text = ("" + num2);
            inputBox.Text = ("0");
        }

        private void calcButton_Click(object sender, EventArgs e)
        {
            Random n = new Random();
            int num1 = int.Parse(num1Label.Text);
            int num2 = int.Parse(num2Label.Text);
            int input = int.Parse(inputBox.Text);

            int answer = num1 + num2;

            if(answer == input)
            {
                MessageBox.Show("You got it! " + num1 + " plus " + num2 + " eguals " + input + "!");
                num1 = n.Next(100, 500);
                num2 = n.Next(100, 500);
                inputBox.Text = ("0");
                num1Label.Text = ("" + num1);
                num2Label.Text = ("" + num2);
            }
            if (answer != input)
            {
                MessageBox.Show("Nope, sorry! " + num1 + " plus " + num2 + " equals " + answer + " ...");
                num1 = n.Next(100, 500);
                num2 = n.Next(100, 500);
                inputBox.Text = ("0");
                num1Label.Text = ("" + num1);
                num2Label.Text = ("" + num2);
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
