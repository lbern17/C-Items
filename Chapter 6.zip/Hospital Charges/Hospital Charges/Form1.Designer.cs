﻿namespace Hospital_Charges
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.welcomeLabel = new System.Windows.Forms.Label();
            this.instructLabel = new System.Windows.Forms.Label();
            this.nightsLabel = new System.Windows.Forms.Label();
            this.daysBox = new System.Windows.Forms.TextBox();
            this.surgeryLabel = new System.Windows.Forms.Label();
            this.labLabel = new System.Windows.Forms.Label();
            this.rehabLabel = new System.Windows.Forms.Label();
            this.medLabel = new System.Windows.Forms.Label();
            this.surgeryBox = new System.Windows.Forms.TextBox();
            this.labBox = new System.Windows.Forms.TextBox();
            this.rehabBox = new System.Windows.Forms.TextBox();
            this.medBox = new System.Windows.Forms.TextBox();
            this.calcButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // welcomeLabel
            // 
            this.welcomeLabel.AutoSize = true;
            this.welcomeLabel.Location = new System.Drawing.Point(35, 9);
            this.welcomeLabel.Name = "welcomeLabel";
            this.welcomeLabel.Size = new System.Drawing.Size(212, 13);
            this.welcomeLabel.TabIndex = 0;
            this.welcomeLabel.Text = "Welcome to the Hospital Charges Machine!";
            // 
            // instructLabel
            // 
            this.instructLabel.AutoSize = true;
            this.instructLabel.Location = new System.Drawing.Point(17, 31);
            this.instructLabel.Name = "instructLabel";
            this.instructLabel.Size = new System.Drawing.Size(255, 13);
            this.instructLabel.TabIndex = 1;
            this.instructLabel.Text = "Input the Relevant Information into the Boxes Below:";
            // 
            // nightsLabel
            // 
            this.nightsLabel.AutoSize = true;
            this.nightsLabel.Location = new System.Drawing.Point(17, 61);
            this.nightsLabel.Name = "nightsLabel";
            this.nightsLabel.Size = new System.Drawing.Size(139, 13);
            this.nightsLabel.TabIndex = 2;
            this.nightsLabel.Text = "# of Days Spent in Hospital:";
            // 
            // daysBox
            // 
            this.daysBox.Location = new System.Drawing.Point(190, 58);
            this.daysBox.Name = "daysBox";
            this.daysBox.Size = new System.Drawing.Size(100, 20);
            this.daysBox.TabIndex = 3;
            // 
            // surgeryLabel
            // 
            this.surgeryLabel.AutoSize = true;
            this.surgeryLabel.Location = new System.Drawing.Point(17, 92);
            this.surgeryLabel.Name = "surgeryLabel";
            this.surgeryLabel.Size = new System.Drawing.Size(143, 13);
            this.surgeryLabel.TabIndex = 4;
            this.surgeryLabel.Text = "Amount Charged for Surgery:";
            // 
            // labLabel
            // 
            this.labLabel.AutoSize = true;
            this.labLabel.Location = new System.Drawing.Point(17, 117);
            this.labLabel.Name = "labLabel";
            this.labLabel.Size = new System.Drawing.Size(154, 13);
            this.labLabel.TabIndex = 5;
            this.labLabel.Text = "Amount Charged for Lab Tests:";
            // 
            // rehabLabel
            // 
            this.rehabLabel.AutoSize = true;
            this.rehabLabel.Location = new System.Drawing.Point(-1, 142);
            this.rehabLabel.Name = "rehabLabel";
            this.rehabLabel.Size = new System.Drawing.Size(191, 17);
            this.rehabLabel.TabIndex = 6;
            this.rehabLabel.Text = "Amount Charged for Physical Rehab:";
            this.rehabLabel.UseCompatibleTextRendering = true;
            // 
            // medLabel
            // 
            this.medLabel.AutoSize = true;
            this.medLabel.Location = new System.Drawing.Point(20, 168);
            this.medLabel.Name = "medLabel";
            this.medLabel.Size = new System.Drawing.Size(170, 17);
            this.medLabel.TabIndex = 7;
            this.medLabel.Text = "Amount Charged for Medication::";
            this.medLabel.UseCompatibleTextRendering = true;
            // 
            // surgeryBox
            // 
            this.surgeryBox.Location = new System.Drawing.Point(190, 84);
            this.surgeryBox.Name = "surgeryBox";
            this.surgeryBox.Size = new System.Drawing.Size(100, 20);
            this.surgeryBox.TabIndex = 8;
            // 
            // labBox
            // 
            this.labBox.Location = new System.Drawing.Point(190, 110);
            this.labBox.Name = "labBox";
            this.labBox.Size = new System.Drawing.Size(100, 20);
            this.labBox.TabIndex = 9;
            // 
            // rehabBox
            // 
            this.rehabBox.Location = new System.Drawing.Point(190, 139);
            this.rehabBox.Name = "rehabBox";
            this.rehabBox.Size = new System.Drawing.Size(100, 20);
            this.rehabBox.TabIndex = 10;
            // 
            // medBox
            // 
            this.medBox.Location = new System.Drawing.Point(190, 168);
            this.medBox.Name = "medBox";
            this.medBox.Size = new System.Drawing.Size(100, 20);
            this.medBox.TabIndex = 11;
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(104, 194);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(96, 42);
            this.calcButton.TabIndex = 12;
            this.calcButton.Text = "Calculate";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(302, 261);
            this.Controls.Add(this.calcButton);
            this.Controls.Add(this.medBox);
            this.Controls.Add(this.rehabBox);
            this.Controls.Add(this.labBox);
            this.Controls.Add(this.surgeryBox);
            this.Controls.Add(this.medLabel);
            this.Controls.Add(this.rehabLabel);
            this.Controls.Add(this.labLabel);
            this.Controls.Add(this.surgeryLabel);
            this.Controls.Add(this.daysBox);
            this.Controls.Add(this.nightsLabel);
            this.Controls.Add(this.instructLabel);
            this.Controls.Add(this.welcomeLabel);
            this.Name = "Form1";
            this.Text = "Hospital Charges";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label welcomeLabel;
        private System.Windows.Forms.Label instructLabel;
        private System.Windows.Forms.Label nightsLabel;
        private System.Windows.Forms.TextBox daysBox;
        private System.Windows.Forms.Label surgeryLabel;
        private System.Windows.Forms.Label labLabel;
        private System.Windows.Forms.Label rehabLabel;
        private System.Windows.Forms.Label medLabel;
        private System.Windows.Forms.TextBox surgeryBox;
        private System.Windows.Forms.TextBox labBox;
        private System.Windows.Forms.TextBox rehabBox;
        private System.Windows.Forms.TextBox medBox;
        private System.Windows.Forms.Button calcButton;
    }
}

