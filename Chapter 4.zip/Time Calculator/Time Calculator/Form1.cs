﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Time_Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calcButton_Click(object sender, EventArgs e)
        {
            int sec; //Seconds
            sec = int.Parse(secondBox.Text);
            int min = sec / 60;
            minutesBox.Text = ("" + min);
            int hour = sec / 3600;
            hourBox.Text = ("" + hour);
            int day = sec / 86400;
            dayBox.Text = ("" + day);
        }
    }
}
