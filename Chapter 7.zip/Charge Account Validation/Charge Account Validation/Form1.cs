﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Charge_Account_Validation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void valButton_Click(object sender, EventArgs e)
        {
            List<int> accounts = new List<int>();

            int accountNum = int.Parse(accountBox.Text);

            StreamReader inputFile = File.OpenText("ChargeAccounts.txt");

            while (!inputFile.EndOfStream)
            {
                accounts.Add(int.Parse(inputFile.ReadLine()));
            }

            inputFile.Close();

            bool accountFound = false;

            foreach(int account in accounts)
            {
                if (account == accountNum)
                {
                    accountFound = true;
                }

            }

            if (accountFound)
            {
                MessageBox.Show("This is a valid account number!");
            }
            else
            {
                MessageBox.Show("This is not a valid account number! Just what con are you trying to pull?");
            }
        }



        }
    }
